"""Bounded HTTPS GET capability client. No network interface or TLS stack is needed in the sandbox."""
import json
import socket

class FetchDenied(RuntimeError):
    pass

def fetch(url, socket_path='/.microbox-egress/fetch.sock', timeout=10, max_response_bytes=1024*1024):
    if not isinstance(url, str) or len(url.encode())>4000:
        raise ValueError('URL exceeds request bound')
    request=json.dumps({'url':url},separators=(',',':')).encode()+b'\n'
    with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as stream:
        stream.settimeout(timeout)
        stream.connect(socket_path)
        stream.sendall(request)
        data=bytearray()
        while True:
            chunk=stream.recv(4096)
            if not chunk:
                raise FetchDenied('proxy_closed')
            data.extend(chunk)
            if len(data)>2*max_response_bytes+1024:
                raise FetchDenied('response_bound_exceeded')
            if b'\n' in data:
                break
    response=json.loads(data)
    if response.get('outcome')!='fetched':
        raise FetchDenied(response.get('reason','invalid_response'))
    body=bytes.fromhex(response['body_hex'])
    if len(body)>max_response_bytes:
        raise FetchDenied('response_bound_exceeded')
    return response['status'],body
